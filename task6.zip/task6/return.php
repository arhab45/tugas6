<?php
//Membuat Fungsi
function perkenalan($nama, $salam){
  echo $salam.",";
  echo "Perkenalkan, nama saya ".$nama."<br/>";
  echo "Senang berkenalan dengan anda<br/>";
}

//memanggil fungsi yang sudah dibuat
perkenalan("Usro", "Hai");

echo "<hr/>";

$saya = "Bedu";
$ucapanSalam = "Selamat Pagi";

//memanggilnya lagi
perkenalan($saya, $ucapanSalam);

echo '<br/>';

//Membuat fungsi
function hitungUmur($thn_lahir, $thn_sekarang){
  $umur = $thn_sekarang - $thn_lahir;
  return $umur;
}

echo "Umur saya adalah ". hitungUmur(2003, 2022) ." tahun";




   ?>