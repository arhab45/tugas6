<?php
function pangkatDua($a){
    global $a;
    $a = $a * $a;
  }
  $a =20;
  echo 'Sebelum Nila $a :' .$a;
  pangkatDua($a);
  echo '<br/>Sesudah Nlai $a :' .$a;
?>