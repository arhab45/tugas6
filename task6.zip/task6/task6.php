<?php
// string function 
$nama = "muhammad raden iqbal hafidz fauzi";
echo $nama;
echo '<br/>';
echo strtoupper($nama);
echo '<br/>';
echo ucwords($nama);
echo '<br/>';
echo lcfirst($nama);
echo '<br/>';
echo strtolower($nama);


// Fungsi void
   function salam ($nama){
    echo "<h2>Assalamu'alaikum ".strtoupper($nama)."</h2";
 }

   salam("ali");
   echo '<br/>';
   salam("fadil");
   echo '<br/>';
   salam("yanto");
   echo '<br/>';

   echo '<br/>';
   echo '<br/>';

   //Fungsi return value
   function jumlah($a , $b){
      return $a + $b;
}
   echo '2 + 8 = '.jumlah(2,8);
   
   echo '<br/>';
   echo '<br/>';
   
   //Membuat Fungsi
   function perkenalan(){
      echo "Assalamu'alaikum,";
      echo "Perkenalkan, nama saya Bedu<br/>";
      echo "senang berkenalan dengan anda<br/>";
   }
   //memanggil fungsi yang sudah dibuat
   perkenalan();

   echo "<hr/>";

   //memanggil lagi
   perkenalan();

   
?>
